import SwiftUI
@main
struct StudentNoteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
